<!-- Fav Icon -->
<link rel="icon" href="{{asset('frontend/images/favicon.ico')}}" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Arimo:400,400i,700,700i&amp;display=swap" rel="stylesheet">

<link href="{{asset('frontend/css/font-awesome-all.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/flaticon.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/owl.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/bootstrap.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/jquery.fancybox.min.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/animate.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/color.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/rtl.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/style.css')}}" rel="stylesheet">
<link href="{{asset('frontend/css/responsive.css')}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset('frontend/css/customFooter.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/customCss.css')}}">
<link rel="stylesheet" href="{{asset('frontend/css/customGrid.css')}}">

<link rel="stylesheet" href="{{asset('frontend/css/customForm.css')}}" />
<link rel="stylesheet" href="{{asset('frontend/css/customFilter.css')}}">
@stack('style')