<!-- jequery plugins -->
<script src="{{asset('frontend/js/jquery.js')}}"></script>
<script src="{{asset('frontend/js/popper.min.js')}}"></script>
<script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
<script src="{{asset('frontend/js/owl.js')}}"></script>
<script src="{{asset('frontend/js/wow.js')}}"></script>
<script src="{{asset('frontend/js/validation.js')}}"></script>
<script src="{{asset('frontend/js/jquery.fancybox.js')}}"></script>
<script src="{{asset('frontend/js/appear.js')}}"></script>
<script src="{{asset('frontend/js/jquery.countTo.js')}}"></script>
<script src="{{asset('frontend/js/scrollbar.js')}}"></script>
<script src="{{asset('frontend/js/nav-tool.js')}}"></script>
<script src="{{asset('frontend/js/TweenMax.min.js')}}"></script>
<script src="{{asset('frontend/js/circle-progress.js')}}"></script>
{{-- <script src="{{asset('frontend/js/jquery.nice-select.min.js')}}"></script> --}}
<!-- map script -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-CE0deH3Jhj6GN4YvdCFZS7DpbXexzGU"></script>
<script src="{{asset('frontend/js/gmaps.js')}}"></script>
<script src="{{asset('frontend/js/map-helper.js')}}"></script>
<!-- main-js -->
<script src="{{asset('frontend/js/script.js')}}"></script>
@stack('scripts')